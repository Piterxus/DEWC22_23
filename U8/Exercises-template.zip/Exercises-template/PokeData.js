
function PokeData(props) {

  // Your code here

  return (
    <>
      <h2>PokeData</h2>
      <div className='pokedata'>
          <img alt="pokemon image" />
      </div>
    </>
  )
}

export default PokeData
