import './loader.css'

function Loading(props) {
  
  // Your code here

  return (
    <div className="loading">
      <div className="loader"></div>
    </div>
  )
}

export default Loading
