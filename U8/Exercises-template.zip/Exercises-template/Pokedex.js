
import './pokedex.css'

function Pokedex() {

  return (
    <div>
      <h1>Pokedex</h1>
      {
        // Render PokeForm here
        // Render PokeData here
      }
    </div>
  )
}

export default Pokedex
